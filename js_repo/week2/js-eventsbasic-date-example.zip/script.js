function displayDate(){
		document.getElementById("demo").innerHTML=Date();
	}