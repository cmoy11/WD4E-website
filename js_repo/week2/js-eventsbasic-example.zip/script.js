function message(msg)
	{
  		document.getElementById('output').innerHTML = msg + " event";
	}