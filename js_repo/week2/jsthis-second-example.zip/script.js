function showProperties(element){
  document.getElementById('message').innerHTML = element.alt;
}