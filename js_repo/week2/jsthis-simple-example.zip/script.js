function displayId(element){
  console.log(element.id);
}