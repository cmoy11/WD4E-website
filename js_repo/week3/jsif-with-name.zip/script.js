var name = prompt("What is your name?")

if (name.length != 0){
    document.write("Hello " +  name)
}
else
  document.write("Feeling shy?")